/*******************************************************************************
    Copyright 2008 Sun Microsystems, Inc.,
    4150 Network Circle, Santa Clara, California 95054, U.S.A.
    All rights reserved.

    U.S. Government Rights - Commercial software.
    Government users are subject to the Sun Microsystems, Inc. standard
    license agreement and applicable provisions of the FAR and its supplements.

    Use is subject to license terms.

    This distribution may include materials developed by third parties.

    Sun, Sun Microsystems, the Sun logo and Java are trademarks or registered
    trademarks of Sun Microsystems, Inc. in the U.S. and other countries.
 ******************************************************************************/

package com.sun.fortress.interpreter.evaluator;

import static com.sun.fortress.exceptions.InterpreterBug.bug;
import static com.sun.fortress.exceptions.ProgramError.error;
import static com.sun.fortress.exceptions.ProgramError.errorMsg;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Stack;
import java.util.concurrent.Callable;

import com.sun.fortress.exceptions.FortressError;
import com.sun.fortress.exceptions.FortressException;
import com.sun.fortress.exceptions.LabelException;
import com.sun.fortress.exceptions.NamedLabelException;
import com.sun.fortress.exceptions.ProgramError;
import com.sun.fortress.exceptions.transactions.AbortedException;
import com.sun.fortress.interpreter.Driver;
import com.sun.fortress.interpreter.env.BetterEnv;
import com.sun.fortress.interpreter.evaluator.tasks.BaseTask;
import com.sun.fortress.interpreter.evaluator.tasks.FortressTaskRunner;
import com.sun.fortress.interpreter.evaluator.tasks.TupleTask;
import com.sun.fortress.interpreter.evaluator.types.FTraitOrObject;
import com.sun.fortress.interpreter.evaluator.types.FType;
import com.sun.fortress.interpreter.evaluator.types.FTypeTuple;
import com.sun.fortress.interpreter.evaluator.values.Closure;
import com.sun.fortress.interpreter.evaluator.values.Constructor;
import com.sun.fortress.interpreter.evaluator.values.DottedMethodApplication;
import com.sun.fortress.interpreter.evaluator.values.FAsIf;
import com.sun.fortress.interpreter.evaluator.values.FBool;
import com.sun.fortress.interpreter.evaluator.values.FChar;
import com.sun.fortress.interpreter.evaluator.values.FFloatLiteral;
import com.sun.fortress.interpreter.evaluator.values.FGenericFunction;
import com.sun.fortress.interpreter.evaluator.values.FIntLiteral;
import com.sun.fortress.interpreter.evaluator.values.FObject;
import com.sun.fortress.interpreter.evaluator.values.FString;
import com.sun.fortress.interpreter.evaluator.values.FTuple;
import com.sun.fortress.interpreter.evaluator.values.FValue;
import com.sun.fortress.interpreter.evaluator.values.FVoid;
import com.sun.fortress.interpreter.evaluator.values.Fcn;
import com.sun.fortress.interpreter.evaluator.values.GenericConstructor;
import com.sun.fortress.interpreter.evaluator.values.GenericSingleton;
import com.sun.fortress.interpreter.evaluator.values.IUOTuple;
import com.sun.fortress.interpreter.evaluator.values.Method;
import com.sun.fortress.interpreter.evaluator.values.MethodClosure;
import com.sun.fortress.interpreter.evaluator.values.OverloadedFunction;
import com.sun.fortress.interpreter.evaluator.values.Selectable;
import com.sun.fortress.interpreter.glue.Glue;
import com.sun.fortress.interpreter.glue.WellKnownNames;
import com.sun.fortress.nodes.APIName;
import com.sun.fortress.nodes.AbstractFieldRef;
import com.sun.fortress.nodes.AbstractNode;
import com.sun.fortress.nodes.AmbiguousMultifixOpExpr;
import com.sun.fortress.nodes.ArgExpr;
import com.sun.fortress.nodes.ArrayComprehension;
import com.sun.fortress.nodes.ArrayComprehensionClause;
import com.sun.fortress.nodes.ArrayElement;
import com.sun.fortress.nodes.ArrayElements;
import com.sun.fortress.nodes.ArrayExpr;
import com.sun.fortress.nodes.AsExpr;
import com.sun.fortress.nodes.AsIfExpr;
import com.sun.fortress.nodes.Assignment;
import com.sun.fortress.nodes.AtomicExpr;
import com.sun.fortress.nodes.BaseType;
import com.sun.fortress.nodes.Block;
import com.sun.fortress.nodes.CaseClause;
import com.sun.fortress.nodes.CaseExpr;
import com.sun.fortress.nodes.Catch;
import com.sun.fortress.nodes.CatchClause;
import com.sun.fortress.nodes.ChainExpr;
import com.sun.fortress.nodes.CharLiteralExpr;
import com.sun.fortress.nodes.Do;
import com.sun.fortress.nodes.DoFront;
import com.sun.fortress.nodes.Enclosing;
import com.sun.fortress.nodes.Exit;
import com.sun.fortress.nodes.ExponentiationMI;
import com.sun.fortress.nodes.Expr;
import com.sun.fortress.nodes.ExprMI;
import com.sun.fortress.nodes.ExtentRange;
import com.sun.fortress.nodes.FieldRef;
import com.sun.fortress.nodes.FloatLiteralExpr;
import com.sun.fortress.nodes.FnExpr;
import com.sun.fortress.nodes.FnRef;
import com.sun.fortress.nodes.GeneratorClause;
import com.sun.fortress.nodes.Id;
import com.sun.fortress.nodes.If;
import com.sun.fortress.nodes.IfClause;
import com.sun.fortress.nodes.IntLiteralExpr;
import com.sun.fortress.nodes.Juxt;
import com.sun.fortress.nodes.KeywordExpr;
import com.sun.fortress.nodes.LValueBind;
import com.sun.fortress.nodes.Label;
import com.sun.fortress.nodes.LetExpr;
import com.sun.fortress.nodes.Lhs;
import com.sun.fortress.nodes.Link;
import com.sun.fortress.nodes.LooseJuxt;
import com.sun.fortress.nodes.MathItem;
import com.sun.fortress.nodes.MathPrimary;
import com.sun.fortress.nodes.MethodInvocation;
import com.sun.fortress.nodes.Name;
import com.sun.fortress.nodes.Node;
import com.sun.fortress.nodes.NonExprMI;
import com.sun.fortress.nodes.NonParenthesisDelimitedMI;
import com.sun.fortress.nodes.Op;
import com.sun.fortress.nodes.OpExpr;
import com.sun.fortress.nodes.OpName;
import com.sun.fortress.nodes.OpRef;
import com.sun.fortress.nodes.Param;
import com.sun.fortress.nodes.ParenthesisDelimitedMI;
import com.sun.fortress.nodes.StaticArg;
import com.sun.fortress.nodes.StringLiteralExpr;
import com.sun.fortress.nodes.SubscriptExpr;
import com.sun.fortress.nodes.SubscriptingMI;
import com.sun.fortress.nodes.Throw;
import com.sun.fortress.nodes.TightJuxt;
import com.sun.fortress.nodes.Try;
import com.sun.fortress.nodes.TryAtomicExpr;
import com.sun.fortress.nodes.TupleExpr;
import com.sun.fortress.nodes.Type;
import com.sun.fortress.nodes.Typecase;
import com.sun.fortress.nodes.TypecaseClause;
import com.sun.fortress.nodes.UnpastingBind;
import com.sun.fortress.nodes.UnpastingSplit;
import com.sun.fortress.nodes.VarRef;
import com.sun.fortress.nodes.VoidLiteralExpr;
import com.sun.fortress.nodes.While;
import com.sun.fortress.nodes._RewriteFieldRef;
import com.sun.fortress.nodes._RewriteFnApp;
import com.sun.fortress.nodes._RewriteFnRef;
import com.sun.fortress.nodes._RewriteObjectExpr;
import com.sun.fortress.nodes._RewriteObjectExprRef;
import com.sun.fortress.nodes._RewriteObjectRef;
import com.sun.fortress.nodes_util.ExprFactory;
import com.sun.fortress.nodes_util.NodeUtil;
import com.sun.fortress.nodes_util.OprUtil;
import com.sun.fortress.nodes_util.Span;
import com.sun.fortress.useful.HasAt;
import com.sun.fortress.useful.NI;
import com.sun.fortress.useful.Pair;
import com.sun.fortress.useful.Useful;

import edu.rice.cs.plt.iter.IterUtil;
import edu.rice.cs.plt.tuple.Option;

public class Evaluator extends EvaluatorBase<FValue> {
     boolean debug = false;
    final private static boolean isArgExpr = false;

    public FValue eval(Expr e) {
        return e.accept(this);
    }

    /**
     * Creates a new evaluator in a primitive environment.
     *
     */
    public Evaluator(HasAt within) {
        this(BetterEnv.primitive(within));
    }

    /**
     * Creates a new com.sun.fortress.interpreter.evaluator in a nested scope. The "frame" created for the
     * extension to the environment is tagged by within.
     *
     * @param ev
     * @param within
     */
    public Evaluator(Evaluator ev, HasAt within) {
        this(ev.e.extendAt(within));
    }

    /**
     * Creates a new com.sun.fortress.interpreter.evaluator in the specified environment.
     */
    public Evaluator(Environment e) {
        super(e);
        this.e.bless();
    }

    /**
     * Useful for evaluators that differ only a little.
     *
     * @param e2
     */
    protected Evaluator(Evaluator e2) {
        super(e2.e);
        debug = e2.debug;
    }

    public FValue NI(String s) {
        return bug(this.getClass().getName() + "." + s + " not implemented");
    }

    public FValue NI(String s, AbstractNode n) {
        return bug(n, this.getClass().getName() + "." + s
                + " not implemented, input \n" + NodeUtil.dump(n));
    }

    public FValue defaultCase(Node n) {
        return bug(n, errorMsg("Cannot evaluate the node ",n," of type ",n.getClass()));
    }

    public FValue forAsExpr(AsExpr x) {
        final Expr expr = x.getExpr();
        FValue val = expr.accept(this);
        Type ty = x.getType();
        FType fty = EvalType.getFType(ty, e);
        if (val.type().subtypeOf(fty))
            return val;
        else
            return error(x, e, errorMsg("The type of expression ", val.type(),
                                        " is not a subtype of ", fty, "."));
    }

    public FValue forAsIfExpr(AsIfExpr x) {
        final Expr expr = x.getExpr();
        FValue val = expr.accept(this);
        Type ty = x.getType();
        FType fty = EvalType.getFType(ty, e);
        if (val.type().subtypeOf(fty))
            return new FAsIf(val,fty);
        else
            return error(x, e, errorMsg("Type of expression, ", val.type(),
                                        ", not a subtype of ", fty, "."));
    }

    // We ask lhs to accept twice (with this and an LHSEvaluator) in
    // the operator case. Might this cause the world to break?
    public FValue forAssignment(Assignment x) {
        Option<OpRef> possOp = x.getOpr();
        LHSToLValue getLValue = new LHSToLValue(this);
        List<? extends Lhs> lhses = getLValue.inParallel(x.getLhs());
        int lhsSize = lhses.size();
        FValue rhs = x.getRhs().accept(this);

        if (possOp.isSome()) {
            // We created an lvalue for lhses above, so there should
            // be no fear of duplicate evaluation.
            OpRef opr_ = possOp.unwrap();
            //OpName opr = opr_.getOriginalName();
            Fcn fcn = (Fcn) getOp(opr_);// opr.accept(this);
            FValue lhsValue;
            if (lhsSize > 1) {
                // TODO:  An LHS walks, talks, and barks just like
                // an Expr in this context.  Yet it isn't an Expr, and
                // we can't pass the lhses to the numerous functions
                // which expect a List<Expr>---for example ArgExpr
                // or evalExprListParallel!  This is extremely annoying!
                List<FValue> lhsComps = new ArrayList<FValue>(lhsSize);
                for (Lhs lhs : lhses) {
                    // This should occur in parallel!!!
                    lhsComps.add(lhs.accept(this));
                }
                lhsValue = FTuple.make(lhsComps);
            } else {
                lhsValue = lhses.get(0).accept(this);
            }
            List<FValue> vargs = new ArrayList<FValue>(2);
            vargs.add(lhsValue);
            vargs.add(rhs);
            rhs = functionInvocation(vargs, fcn, x);
        }

        // Assignment must be single-anything, or tuple-tuple with
        // matched sizes.
        Iterator<FValue> rhsIt = null;
        if (lhsSize > 1 && rhs instanceof FTuple) {
            FTuple rhs_tuple = (FTuple) rhs;
            rhsIt = rhs_tuple.getVals().iterator();
            // Verify, now, that LHS and RHS sizes match.
            if (rhs_tuple.getVals().size() != lhsSize) {
                error(x,e,
                      errorMsg("Tuple assignment size mismatch, | lhs | = ",
                               lhsSize, ", | rhs | = ",
                               rhs_tuple.getVals().size()));
            }
        } else if (lhsSize != 1) {
            error(x,e,
                  errorMsg("Tuple assignment size mismatch, | lhs | = ",
                           lhsSize, ", rhs is not a tuple"));
        }

        for (Lhs lhs : lhses) {
            if (rhsIt != null) {
                rhs = rhsIt.next();
            }
            lhs.accept(new ALHSEvaluator(this, rhs));
        }

        return FVoid.V;
    }

    public FValue forAtomicExpr(AtomicExpr x) {
        final Expr expr = x.getExpr();
        final Evaluator current = new Evaluator(this);
        FValue res = FVoid.V;
        try {
            res = FortressTaskRunner.doIt (
                                           new Callable<FValue>() {
                                               public FValue call() {
                                                   Evaluator ev = new Evaluator(current.e.extendAt(expr));
                                                   return expr.accept(ev);
                                               }
                                           }
                                           );
        } catch (RuntimeException re) {
            throw re;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return res;
    }

    public FValue forTryAtomicExpr(TryAtomicExpr x) {
        final Expr expr = x.getExpr();
        final Evaluator current = new Evaluator(this);
        FValue res = FVoid.V;
        // Inside a transaction tryAtomic is a noop
        // Why is this?  It seems inconsistent with the rest of our transaction story.  chf
        if (FortressTaskRunner.inATransaction()) {
            Evaluator ev = new Evaluator(current.e.extendAt(expr));
            return expr.accept(ev);
        }
        try {
            res = FortressTaskRunner.doItOnce(
                new Callable<FValue>() {
                    public FValue call() {
                        Evaluator ev = new Evaluator(current.e.extendAt(expr));
                        FValue res1 = expr.accept(ev);
                        return res1;
                    }
                }
                                              );
        } catch (AbortedException ae) {
            FObject f = (FObject) Driver.getFortressLibrary().getValue(WellKnownNames.tryatomicFailureException);
            FortressError f_exc = new FortressError(f);
            throw f_exc;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return res;
    }

    public FValue forKeywordExpr(KeywordExpr x) {
        return NI("forKeywordExpr");
    }

    public FValue forDo(Do x) {
        int s = x.getFronts().size();
        if (s == 0) return FVoid.V;
        if (s == 1) {
            DoFront f = x.getFronts().get(0);
            if (f.getLoc().isSome()) {
                Expr regionExp = f.getLoc().unwrap();
                FValue region = regionExp.accept(this);
            }
            if (f.isAtomic())
                return forAtomicExpr(new AtomicExpr(x.getSpan(), false,
                                                    f.getExpr()));
            return f.getExpr().accept(new Evaluator(this));
       }

       TupleTask[] tasks = new TupleTask[s];
       List<Expr> locs = new ArrayList<Expr>(0);
       for (int i = 0; i < s; i++) {
           DoFront f = x.getFronts().get(i);
           if (f.getLoc().isSome()) {
               locs.add(f.getLoc().unwrap());
           }
           if (f.isAtomic())
               tasks[i] = new TupleTask(new AtomicExpr(x.getSpan(), false,
                                                       f.getExpr()), this);
           else
               tasks[i] = new TupleTask(f.getExpr(), new Evaluator(this));
       }
       if (locs.size()>0) {
           List<FValue> regions = evalExprListParallel(locs);
       }
       BaseTask currentTask = FortressTaskRunner.getTask();
       TupleTask.forkJoin(tasks);
       FortressTaskRunner.setCurrentTask(currentTask);

       for (int i = 0; i < s; i++) {
           if (tasks[i].causedException()) {
               Throwable t = tasks[i].taskException();
               if (t instanceof Error) {
                   throw (Error)t;
               } else if (t instanceof RuntimeException) {
                   throw (RuntimeException)t;
               } else {
                   error(x.getFronts().get(i), errorMsg("Wrapped Exception",t));
               }
           }
       }
       return FVoid.V;
    }

    public FValue forBlock(Block x) {
        List<Expr> exprs = x.getExprs();
        return evalExprList(exprs, x);
    }

    /**
     * Returns a list containing the evaluation of exprs.
     * The expressions in the list should not be Lets.
     *
     * @param exprs
     * @return
     */
     <T extends Expr> List<FValue> evalExprList(List<T> exprs) {
        List<FValue> res = new ArrayList<FValue>(exprs.size());
        return evalExprList(exprs, res);
    }

    /**
     * Appends the evaluation of exprs to res.
     * The expressions in the list should not be Lets.
     *
     * @param <T>
     * @param exprs
     * @param res
     * @return
     */
    <T extends Expr> List<FValue> evalExprList(List<T> exprs, List<FValue> res) {
        for (Expr expr : exprs) {
            res.add(expr.accept(this));
        }
        return res;
    }

    public FValue evalExprList(List<Expr> exprs, AbstractNode tag) {
        return evalExprList(exprs, tag, this);
    }

    /**
     * Returns the evaluation of a list of (general) exprs, returning the
     * result of evaluating the last expr in the list.
     * Does the "right thing" with LetExprs.
     */
    public FValue evalExprList(List<Expr> exprs, AbstractNode tag,
                               Evaluator eval) {
        FValue res = FVoid.V;
        for (Expr exp : exprs) {
            // TODO This will get turned into forLet methods
            if (exp instanceof LetExpr) {
                Environment inner = eval.e.extendAt(exp);
                BuildLetEnvironments be = new BuildLetEnvironments(inner);
                    res = be.doLets((LetExpr) exp);
            } else {
                    res = exp.accept(eval);
            }
        }
        return res;
    }


    <T extends Expr> List<FValue> evalExprListParallel(List<T> exprs) {
        // Added some special-case code to avoid explosion of TupleTasks.
        int sz = exprs.size();
        ArrayList<FValue> resList = new ArrayList<FValue>(sz);

        if (sz==1) {
            resList.add(exprs.get(0).accept(this));
        } else if (sz > 1) {
            TupleTask[] tasks = new TupleTask[exprs.size()];
            int count = 0;
            for (Expr e : exprs) {
                tasks[count++] = new TupleTask(e, this);
            }
            BaseTask currentTask = FortressTaskRunner.getTask();
            TupleTask.forkJoin(tasks);
            FortressTaskRunner.setCurrentTask(currentTask);
            for (int i = 0; i < count; i++) {
                if (tasks[i].causedException()) {
                    Throwable t = tasks[i].taskException();
                    if (t instanceof Error) {
                        throw (Error)t;
                    } else if (t instanceof RuntimeException) {
                        throw (RuntimeException)t;
                    } else {
                        error(exprs.get(i), errorMsg("Wrapped Exception",t));
                    }
                }
                resList.add(tasks[i].getRes());
            }
        }
        return resList;
    }

    CaseClause findExtremum(CaseExpr x, Fcn fcn ) {
        List<CaseClause> clauses = x.getClauses();
        Iterator<CaseClause> i = clauses.iterator();

        CaseClause c = i.next();
        FValue winner = c.getMatch().accept(this);
        CaseClause res = c;

        for (; i.hasNext();) {
            c = i.next();
            List<FValue> vargs = new ArrayList<FValue>(2);
            FValue current = c.getMatch().accept(this);
            vargs.add(current);
            vargs.add(winner);
            FValue invoke = functionInvocation(vargs, fcn, x);
            if (!(invoke instanceof FBool)) {
                return error(x,errorMsg("Non-boolean result ",invoke,
                                        " in chain, args ", vargs));
            }
            FBool boolres = (FBool) invoke;
            if (boolres.getBool()) {
                winner = current;
                res = c;
            }
        }
        return res;
    }

    public FValue forCaseExpr(CaseExpr x) {
        List<CaseClause> clauses = x.getClauses();
        Option<Expr> param = x.getParam();
        if (param.isNone()) {
            Option<OpRef> compare = x.getCompare();
            if (compare.isSome()) {
                FValue op = getOp(compare.unwrap());
                return forBlock(findExtremum(x,(Fcn) op).getBody());
            } else
                return error(x,errorMsg("Missing operator for the extremum ",
                                        "expression ", x));
        } else {
            // Evaluate the parameter
            FValue paramValue = param.unwrap().accept(this);
            // Assign a comparison function
            Fcn fcn = (Fcn) e.getValue(x.getEqualsOp());
            Option<OpRef> compare = x.getCompare();
            if (compare.isSome())
                fcn = (Fcn) getOp(compare.unwrap());

            // Iterate through the cases
            for (Iterator<CaseClause> i = clauses.iterator(); i.hasNext();) {
                CaseClause c = i.next();
                // Evaluate the clause
                FValue match = c.getMatch().accept(this);
                List<FValue> vargs = new ArrayList<FValue>();
                vargs.add(paramValue);
                vargs.add(match);
                if (Glue.extendsGenericTrait(match.type(),
                                             WellKnownNames.containsTypeName)) {
                    fcn = (Fcn) Driver.getFortressLibrary().getValue(WellKnownNames.containsMatchName);
                }
                FBool success = (FBool) functionInvocation(vargs, fcn, c);
                if (success.getBool())
                    return forBlock(c.getBody());
            }
            Option<Block> _else = x.getElseClause();
            if (_else.isSome()) {
                // TODO need an Else node to hang a location on
                return forBlock(_else.unwrap());
            }
            FObject f = (FObject) Driver.getFortressLibrary().getValue(WellKnownNames.matchFailureException);
            FortressError f_exc = new FortressError(f);
            throw f_exc;
        }
    }

    /*
     * Only handles 2-ary definitions of chained operators. That should be
     * perfectly wonderful for the moment.
     */
    public FValue forChainExpr(ChainExpr x) {
        Expr first = x.getFirst();
        List<Link> links = x.getLinks();
        FValue idVal = first.accept(this);
        Iterator<Link> i = links.iterator();
        List<FValue> vargs = new ArrayList<FValue>(2);
        if (links.size() == 1) {
            Link link = i.next();
            Fcn fcn = (Fcn) getOp(link.getOp()); // link.getOp().getOriginalName().accept(this);
            FValue exprVal = link.getExpr().accept(this);
            vargs.add(idVal);
            vargs.add(exprVal);
            return functionInvocation(vargs, fcn, x);
        } else {
            FBool boolres = FBool.TRUE;
            vargs.add(idVal);
            vargs.add(idVal);
            while (boolres.getBool() && i.hasNext()) {
                Link link = i.next();
                Fcn fcn = (Fcn) getOp(link.getOp()); // link.getOp().getOriginalName().accept(this);
                FValue exprVal = link.getExpr().accept(this);
                vargs.set(0, idVal);
                vargs.set(1, exprVal);
                FValue invoke = functionInvocation(vargs, fcn, x);
                if (!(invoke instanceof FBool)) {
                    return error(x,errorMsg("Non-boolean result ",invoke,
                                            " in chain, args ", vargs));
                }
                boolres = (FBool)invoke;
                idVal = exprVal;
            }
            return boolres;
        }
    }

    private boolean isShadow(Expr expr, String name) {
        return (expr instanceof VarRef &&
                NodeUtil.nameString(((VarRef)expr).getVar()).equals(name));
    }

    private boolean isShadow(Option<String> var, String name) {
        if (var.isSome()) {
            return var.unwrap().equals(name);
        } else { // var.isNone()
            return false;
        }
    }

    private Option<String> getName(Expr expr) {
        if (expr instanceof VarRef) {
            return Option.some(NodeUtil.nameString(((VarRef)expr).getVar()));
        } else { // !(expr instanceof VarRef)
            return Option.<String>none();
        }
    }

    public List<FType> evalTypeCaseBinding(Evaluator ev, Typecase x) {
        List<Id> bindIds = x.getBindIds();
        Option<Expr> exprOpt = x.getBindExpr();
        Expr expr;
        List<FType> res = new ArrayList<FType>();

        if (exprOpt.isNone()) {
            // HACK/BUG: Looks like problem looking up bind ID within an object context
            // This might always be wrong, if we ever execute this.
            // The missing lexical depth information is the problem.
            for (Id id : bindIds) {
                FValue val = ExprFactory.makeVarRef(id).accept(ev);
                /* Avoid shadow error when we bind the same var name */
                ev.e.putValueRaw(id.getText(), val);
                res.add(val.type());
            }
            throw new Error("maybe this is never executed");
        } else { // exprOpt.isSome()
            expr = exprOpt.unwrap();
            if (bindIds.size() == 1) {
                FValue val = expr.accept(ev);
                String name = bindIds.get(0).getText();
                if (isShadow(expr, name)) {
                    /* Avoid shadow error when we bind the same var name */
                    ev.e.putValueRaw(name, val);
                } else {
                    /* But warn about shadowing in all other cases */
                    ev.e.putValue(name, val);
                }
                res.add(val.type());
            } else { // bindIds.size() > 1
                List<Pair<FValue,Option<String>>> vals =
                    new ArrayList<Pair<FValue,Option<String>>>();
                if (expr instanceof TupleExpr) {
                    for (Expr e : ((TupleExpr)expr).getExprs()) {
                        vals.add(new Pair<FValue,Option<String>>(e.accept(ev),
                                                                 getName(e)));
                    }
                } else { // !(expr instanceof TupleExpr)
                    FValue val = expr.accept(ev);
                    if (!(val instanceof FTuple)) {
                        error(expr, "RHS does not yield a tuple.");
                    }
                    for (FValue v : ((FTuple)val).getVals()) {
                        vals.add(new Pair<FValue,Option<String>>(v, Option.<String>none()));
                    }
                }
                int index = 0;
                for (Id id : bindIds) {
                    String name = id.getText();
                    Pair<FValue,Option<String>> pair = vals.get(index);
                    FValue val = pair.getA();
                    if (isShadow(pair.getB(), name)) {
                        /* Avoid shadow error when we bind the same var name */
                        ev.e.putValueRaw(name, val);
                    } else {
                        /* But warn about shadowing in all other cases */
                        ev.e.putValue(name, val);
                    }
                    res.add(val.type());
                    index++;
                }
            }
        }
        return res;
    }

    private boolean moreSpecificHelper(TypecaseClause candidate,
            TypecaseClause current, Evaluator ev) {
        List<Type> candType = candidate.getMatch();
        List<Type> curType = current.getMatch();
        List<FType> candMatch = EvalType.getFTypeListFromList(candType, ev.e);
        List<FType> curMatch = EvalType.getFTypeListFromList(curType, ev.e);
        boolean res = FTypeTuple.moreSpecificThan(candMatch, curMatch);
        return res;
    }

    // This takes a candidate type clause and list of the best matches so far.
    // It walks down the list comparing the candidate with each match. The
    // winner
    // gets added to the result list. If the candidate beats more than one of
    // the
    // best matches so far, it should only get added to the result list once.

    public List<TypecaseClause> BestMatches(TypecaseClause candidate,
            List<TypecaseClause> bestSoFar, Evaluator ev) {
        List<TypecaseClause> result = new ArrayList<TypecaseClause>();
        boolean addedCandidate = false;

        for (Iterator<TypecaseClause> i = bestSoFar.iterator(); i.hasNext();) {
            TypecaseClause current = i.next();
            if (moreSpecificHelper(candidate, current, ev)) {
                if (!addedCandidate) {
                    result.add(candidate);
                    addedCandidate = true;
                }
            } else if (moreSpecificHelper(current, candidate, ev)) {
                result.add(current);
            } else {
                result.add(current);
                if (!addedCandidate) {
                    result.add(candidate);
                    addedCandidate = true;
                }
            }
        }
        return result;
    }

    public FValue forAPIName(APIName x) {
        String result = "";
        for (Iterator<Id> i = x.getIds().iterator(); i.hasNext();) {
            result = result.concat(i.next().getText());
            if (i.hasNext())
                result = result.concat(".");
        }
        return FString.make(result);
    }

    public FValue forExit(Exit x) {
        Option<Id> target = x.getTarget();
        Option<Expr> returnExpr = x.getReturnExpr();
        FValue res;
        LabelException e;

        if (returnExpr.isSome()) {
            res = returnExpr.unwrap().accept(new Evaluator(this));
        } else {
            res = FVoid.V;
        }

        if (target.isSome()) {
            String t = target.unwrap().getText();
            e = new NamedLabelException(x, t, res);
        } else {
            e = new LabelException(x,res);
        }
        throw e;
    }

    public FValue forExtentRange(ExtentRange x) {
        return NI("forExtentRange");
    }

    @Override
    public FValue forFieldRef(FieldRef x) {
        return forFieldRefCommon(x, x.getField());
    }

    /* (non-Javadoc)
     * @see com.sun.fortress.nodes.NodeAbstractVisitor#for_RewriteFieldRef(com.sun.fortress.nodes._RewriteFieldRef)
     */
    @Override
    public FValue for_RewriteFieldRef(_RewriteFieldRef x) {
        return forFieldRefCommon(x, x.getField());
    }

    private FValue forFieldRefCommon(AbstractFieldRef x, Name fld) throws FortressException,
            ProgramError {
        String fname = NodeUtil.nameString(fld);
        Expr obj = x.getObj();
        FValue fobj = obj.accept(this);
        FValue gv = fobj.getValue();
        try {
            if (gv instanceof Selectable) {
                FValue res = ((Selectable)gv).select(fname);
                if (!(res instanceof Method)) return res;
                // If it's a method, fall through and make dotted method app.
            } else {
                return error(errorMsg("Non-object ",fobj," cannot have field ",
                                      NodeUtil.nameString(fld)));
            }
        } catch (FortressException ex) {
            throw ex.setContext(x,e);
        }
        return DottedMethodApplication.make(fobj,fname,fname,x);
    }

    public FValue forMethodInvocation(MethodInvocation x) {
        Expr obj = x.getObj();
        FValue self = obj.accept(this);
        Expr arg = x.getArg();
        List<FValue> args = argList(arg.accept(this));

        Id method = x.getMethod();
        String mname = NodeUtil.nameString(method);
        List<StaticArg> sargs = x.getStaticArgs();
        if (sargs.isEmpty()) {
            return invokeMethod(self,mname,args,x);
        } else {
            return invokeGenericMethod(self,mname,sargs,args,x);
        }
    }

    public FValue forFnExpr(FnExpr x) {
        Option<Type> return_type = x.getReturnType();
        List<Param> params = x.getParams();
        Closure cl = new Closure(e, x); // , return_type, params);
        cl.finishInitializing();
        return cl;
    }

    public FValue forGeneratorClause(GeneratorClause x) {
        return bug(x,errorMsg("Generator clause "+x+" remains after desugaring"));
    }

    public FValue forId(Id x) {
        return FString.make(x.getText());
    }

    public FValue forIf(If x) {
        List<IfClause> clause = x.getClauses();
        for (Iterator<IfClause> i = clause.iterator(); i.hasNext();) {
            IfClause ifclause = i.next();
            GeneratorClause cond = ifclause.getTest();
            Expr testExpr;
            if (cond.getBind().isEmpty())
                testExpr = cond.getInit();
            else
                testExpr = bug(ifclause,"Undesugared generalized if expression.");
            FValue clauseVal = testExpr.accept(this);
            if (clauseVal instanceof FBool) {
                if (((FBool) clauseVal).getBool()) {
                    return ifclause.getBody().accept(this);
                }
            } else {
                if (clauseVal.type() instanceof FTraitOrObject) {
                    if (((FTraitOrObject)clauseVal.type()).getName().equals("Just"))
                        return ifclause.getBody().accept(this);
                } else {
                    return error(ifclause,
                                 errorMsg("If clause did not return boolean, " +
                                          "but ", clauseVal));
                }
            }
        }
        Option<Block> else_ = x.getElseClause();
        if (else_.isSome()) {
            return else_.unwrap().accept(this);
        }
        else {
            return FVoid.V;
        }
    }

    public FValue forLValueBind(LValueBind x) {
        Id name = x.getName();
        return FString.make(NodeUtil.nameString(name));
    }

    public FValue forLabel(Label x) {
        Id name = x.getName();
        Block body  = x.getBody();
        FValue res = FVoid.V;
        try {
            Evaluator ev = new Evaluator(e.extendAt(body));
            res = ev.forBlock(body);
        } catch (NamedLabelException e) {
            if (e.match(name.getText())) {
                return e.res();
            } else throw e;
        } catch (LabelException e) {
            return e.res();
        }
        return res;
    }

    private FValue juxtApplyStack(Stack<FValue> fns, FValue times, AbstractNode loc) {
        FValue tos = fns.pop();
        while (!fns.empty()) {
            FValue f = fns.pop();

            if (f instanceof Fcn) {
                tos = functionInvocation(argList(tos), f, loc);
            } else {
                tos = functionInvocation(Useful.list(f, tos), times, loc);
            }
        }
        return tos;
    }

    public FValue forLooseJuxt(LooseJuxt x) {
        return forJuxt(x);
    }
    public FValue forJuxt(Juxt x) {
        // This is correct except for one minor detail:
        // We should treat names from another scope as if they were functions.
        // Right now we evaluate them and make the function/non-function
        // distinction based on the resulting getText.
        // We do not handle functional methods, and overlap therewith, at all.
        List<Expr> exprs = x.getExprs();
        FValue times;
        if (exprs.size() == 0)
            bug(x,"empty juxtaposition");
        try {
            // times = e.getValue("juxtaposition");
            times = e.getValueNull(x.getInfixJuxt());
        } catch (FortressException fe) {
            throw fe.setContext(x,e);
        }
        List<FValue> evaled = evalExprListParallel(exprs);
        Boolean inFunction = true;
        Stack<FValue> stack = new Stack<FValue>();
        for (FValue val : evaled) {
            if (val instanceof Fcn) {
                if (!inFunction) {
                    stack.push(juxtApplyStack(stack, times, x));
                    inFunction = true;
                }
                stack.push(val);
            } else if (inFunction) {
                inFunction = false;
                stack.push(val);
            } else {
                FValue r = stack.pop();
                r = functionInvocation(Useful.list(r, val), times, x);
                stack.push(r);
            }
        }
        return juxtApplyStack(stack, times, x);
    }

    @Override
    public FValue for_RewriteFnApp(_RewriteFnApp that) {
        // This method was written by NEB, so there is plenty of reason to believe
        // that I did it incorrectly.

        Expr fn = that.getFunction();
        Expr arg = that.getArgument();

        List<FValue> evaled = evalExprListParallel(Useful.list(fn, arg));

        FValue fn_ = IterUtil.first(evaled);
        FValue arg_ = IterUtil.last(evaled);

        return functionInvocation(arg_, fn_, that);
    }

    public FValue forArrayElement(ArrayElement x) {
        // MDEs occur only within ArrayElements, and reset
        // row evaluation to an outercontext (in the scope
        // of the element, that is).
        return bug(x,"Singleton paste?  Can't judge dimensionality without type inference.");
        // Evaluator notInPaste = new Evaluator(this);
        // return x.getElement().accept(notInPaste);
    }

    /**
     * Evaluates a pasting, outermost.
     *
     * In an outer context, the across-all-dimensions correctness and size
     * information for the IUOTuples can be correctly determined. Until then, it
     * is too early to expand scalars up to full rank.
     */
    public FValue forArrayElements(ArrayElements x) {
        List<ArrayExpr> elements = x.getElements();
        EvaluatorInPaste eip = new EvaluatorInPaste(this);
        List<FValue> values = eip.evalExprList(elements);
        IUOTuple paste = new IUOTuple(values, x);
        // Finish the pasting now.
        paste.finish();
        return paste;
    }

    public FValue for_RewriteObjectExprRef(_RewriteObjectExprRef x) {
        String s = x.getGenSymName();
        // FType ft = e.getType(s);
        // System.out.println("for_RewriteObjectExpr "+s);
        FValue v = e.getTopLevel().getValue(s);

        if (v instanceof GenericConstructor) {
            GenericConstructor gc = (GenericConstructor) v;
            List<StaticArg> args = x.getStaticArgs();
            Constructor cl = (Constructor) gc.typeApply(args, e, x);
            return cl.applyOEConstructor( x, e);
        } else if (v instanceof Constructor) {
            Constructor cl = (Constructor) v;
            // FTypeObject fto = (FTypeObject) ft;
            // cl.setParams(Collections.<Parameter> emptyList());
            // BuildEnvironments.finishObjectTrait(x.getTraits(), fto, e);
            // cl.finishInitializing();
            return cl.applyOEConstructor( x, e);
        } else {
            return bug(x,e, errorMsg("_RewriteObjectExpr ", s,
                                              " has 'constructor' ", v));
        }

        // Option<List<Type>> traits = x.getTraits();
        // List<Decl> defs = x.getDefs();
        // FTypeObject fto = new FTypeObject(genSym(x), e);
        // return BuildEnvironments.anObject(fto, e, traits, defs, x);

    }

    private FValue getOp(OpRef op) {
        try {
            if (op.getLexicalDepth() != Environment.TOP_LEVEL) {
                bug("Expect all oprefs to be top level " + op);
            }
            if (op.getOps().size() != 1)
                bug("Should have rewritten ops to length 1, op="+
                        op + ", list =" + op.getOps());
            FValue v = e.getValue(op.getOps().get(0), Environment.TOP_LEVEL);
            return v;
            //return e.getValue(op);
        } catch (FortressException ex) {
            throw ex.setContext(op,e);
        }
    }

//    public FValue forEnclosing(Enclosing x) {
//        return getOp(x);
//    }
//
//    public FValue forOp(Op op) {
//        return getOp(op);
//    }

    private boolean isExponentiation(OpExpr expr) {
        OpRef ref = expr.getOp();

            OpName name = ref.getOriginalName();
            if (!(name instanceof Op)) return false;
            else return (((Op)name).getText().equals("^") ||
                         OprUtil.isPostfix(name));

    }



    // This method is not necessary in the long run. These nodes will
    // be removed by the static end. For now, since we are not
    // correctly rebuilding the AST in all cases, some are getting
    // through. Just create an OpExpr that is multifix, since that's
    // what the op fixity was before. Talk to me if you think I am
    // dumb. Nels
    @Override
    public FValue forAmbiguousMultifixOpExpr(AmbiguousMultifixOpExpr that) {
        return this.forOpExpr(new OpExpr(that.getSpan(), that.isParenthesized(), that.getMultifix_op(), that.getArgs()));
    }

    /** Assumes {@code x.getOps()} is a list of length 1.  At the
     * moment it appears that this is true for every OpExpr node that
     * is ever created. */
    public FValue forOpExpr(OpExpr x) {
        OpRef ref = x.getOp();

        OpName op = ref.getOriginalName();
        List<Expr> args = x.getArgs();
        FValue fvalue = getOp(ref); //op.accept(this);
        fvalue = applyToStaticArgs(fvalue,ref.getStaticArgs(),ref);
        // Evaluate actual parameters.
        int s = args.size();
        FValue res = FVoid.V;
        List<FValue> vargs;

        if (op instanceof Op && OprUtil.isPostfix(op) &&
            args.size() == 1) {
        // It is a static error if a function argument is immediately followed
        // by a non-expression element.  For example, f(x)!
        // It is a static error if an exponentiation is immediately followed
        // by a non-expression element.  For example, a^b!
            Expr arg = args.get(0);
            if (arg instanceof OpExpr &&
                isExponentiation((OpExpr)arg)) { // a^b!
                vargs = error(arg,
                              "Syntax Error: an exponentiation should not be " +
                              "immediately followed by a non-expression " +
                              "element.");
            } else if (arg instanceof TightJuxt) { // f(x)!
                vargs = Useful.list(forTightJuxt((TightJuxt)arg, true));
            } else if (arg instanceof MathPrimary) { // f(x)^y! y[a](x)!
                vargs = Useful.list(forMathPrimary((MathPrimary)arg, true));
            } else vargs = evalExprListParallel(args);
        } else vargs = evalExprListParallel(args);

        /*
         * It *seems* that the reason we have to have our own version of
         * application here is that we have no simple way to decide for any
         * possible fvalue whether it should be applied at arbitrary arity, or
         * just as a unary or binary call. It would be a lovely simplification
         * if we could make this ball of hair go away (especially since it's not
         * right at the moment!). - Jan
         *
         * The current take on this particular hack is that we treat operators
         * as binary and left-associative, unless they are enclosing. If they
         * are enclosing we perform a full-arity application.
         */

        if (!(fvalue instanceof Fcn)) {
            error(x, e,
                  errorMsg("Operator ", op.stringName(),
                           " has a non-function value ", fvalue));
        }
        Fcn fcn = (Fcn) fvalue;
        if (s <= 2 || (op instanceof Enclosing)) {
            res = functionInvocation(vargs, fcn, x);
        } else {
            List<FValue> argPair = new ArrayList<FValue>(2);
            argPair.add(vargs.get(0));
            argPair.add(vargs.get(1));
            res = functionInvocation(argPair, fcn, x);
            for (int i = 2; i < s; i++) {
                argPair.set(0, res);
                argPair.set(1, vargs.get(i));
                res = functionInvocation(argPair, fcn, x);
            }
        }
        return res;
    }

    public FValue forArrayCompClause(ArrayComprehensionClause x) {
        return NI("forArrayCompClause");
    }

    public FValue forArrayComprehension(ArrayComprehension x) {
        return NI("forArrayComprehension");
    }

    public FValue forStringLiteralExpr(StringLiteralExpr x) {
        return FString.make(x.getText());
    }

    /*
     * (non-Javadoc)
     *
     * @see com.sun.fortress.interpreter.nodes.NodeVisitor#forSubscriptExpr(com.sun.fortress.interpreter.nodes.SubscriptExpr)
     */
    @Override
    public FValue forSubscriptExpr(SubscriptExpr x) {
        Expr obj = x.getObj();
        FValue arr = obj.accept(this);
        List<FValue> subs = evalExprListParallel(x.getSubs());
        Option<Enclosing> op = x.getOp();
        // Should evaluate obj.[](subs, getText)
        String opString = "[]";
        if (op.isSome()) {
            opString = NodeUtil.nameString(op.unwrap());
        }
        return invokeMethod(arr,opString,subs,x);
    }

    // Non-static version provides the obvious arguments.
    public FValue invokeMethod(FValue receiver, String mname, List<FValue> args,
                               HasAt x) {
        return DottedMethodApplication.invokeMethod(receiver,mname,mname,args,x,e);
    }

    // Version that evaluates arguments first.
    public FValue evalAndInvokeMethod(FValue receiver, String mname, List<Expr> args,
                                      HasAt x) {
        return invokeMethod(receiver,mname,evalInvocationArgs(args),x);
    }

    public FValue invokeGenericMethod(FValue receiver, String mname,
                                      List<StaticArg> sargs, List<FValue> args,
                                      HasAt x) {
        DottedMethodApplication app0 =
            DottedMethodApplication.make(receiver,mname,mname,x);
        DottedMethodApplication app = app0.applyToStaticArgs(sargs,x,e);
        return app.apply(args,x,e);
    }

    private boolean isFunction(FValue val) { return (val instanceof Fcn); }
    private boolean isExpr(MathItem mi)    { return (mi instanceof ExprMI); }
    private boolean isParenthesisDelimited(MathItem mi) {
        return (mi instanceof ParenthesisDelimitedMI);
    }
    private MathItem dummyExpr() {
        Span span = new Span();
        Expr dummyE = ExprFactory.makeVoidLiteralExpr(span);
        return new NonParenthesisDelimitedMI(span, dummyE);
    }

    private List<Pair<MathItem,FValue>> stepTwo(List<Pair<MathItem,FValue>> vs,
                                                boolean isPostfix) {
        if (vs.size() < 1) return error("Reassociation of MathPrimary failed!");
        else if (vs.size() == 1) return vs;
        else { // vs.size() > 1
            int ftnInd = 0;
            FValue ftn = vs.get(ftnInd).getB();
            FValue arg;
            MathItem argE = vs.get(ftnInd+1).getA();
            for (Pair<MathItem,FValue> pair : IterUtil.skipFirst(vs)) {
                // 2. If some function element is immediately followed by
                // an expression element then, find the first such function
                // element, and call the next element the argument.
                argE = pair.getA();
                if (isFunction(ftn) && isExpr(argE)) {
                    arg = pair.getB();
                    // It is a static error if either the argument is not
                    // parenthesized, or the argument is immediately followed by
                    // a non-expression element.
                    if (!isParenthesisDelimited(argE))
                       return error(((ExprMI)argE).getExpr(),
                                    "Syntax Error: the " +
                                    "argument is not parenthesized.");
                    if (ftnInd+2 < vs.size() &&
                        !isExpr(vs.get(ftnInd+2).getA()))
                       return error(((ExprMI)argE).getExpr(),
                                    "Syntax Error: the " +
                                    "argument should not be immediately followed by a " +
                                    "non-expression element.");
                    // Otherwise, replace the function and argument with a
                    // single element that is the application of the function to
                    // the argument.  This new element is an expression.
                    Pair<MathItem,FValue> app =
                        new Pair<MathItem,FValue>(dummyExpr(),
                                                  functionInvocation(arg,(Fcn)ftn,argE));
                    vs.set(ftnInd, app);
                    vs.remove(ftnInd+1);
                    // It is a static error if a function argument is immediately
                    // followed by a postfix operator.  For example, y[a](x)!
                    if (isPostfix && vs.size() == 2 &&
                        isFunction(vs.get(0).getB()) && isExpr(vs.get(1).getA()))
                        return error(((ExprMI)vs.get(1).getA()).getExpr(),
                                     "Syntax Error: a " +
                                     "function argument should not be immediately " +
                                     "followed by a postfix operator.");
                    // Reassociate the resulting sequence (which is one element
                    // shorter).
                    return reassociate(vs, isPostfix);
                }
                ftn = pair.getB();
                ftnInd++;
            }
            return vs;
        }
    }

    private FValue mathItemApplication(NonExprMI opr, FValue front,
                                       MathItem loc) {
        if (opr instanceof ExponentiationMI) {
            ExponentiationMI expo = (ExponentiationMI)opr;
            OpName op = expo.getOp().getOriginalName();
            FValue fvalue = getOp(expo.getOp()); //op.accept(this);
            if (!isFunction(fvalue))
                return error(op, errorMsg("Operator ", op.stringName(),
                                          " has a non-function value ", fvalue));
            Option<Expr> expr = expo.getExpr();
            Fcn fcn = (Fcn)fvalue;
            if (expr.isSome()) { // ^ Exponent
                FValue exponent = expr.unwrap().accept(this);
                return functionInvocation(Useful.list(front, exponent), fcn, op);
            } else { // ExponentOp
                return functionInvocation(Useful.list(front), fcn, op);
            }
        } else { // opr instanceof SubscriptingMI
            SubscriptingMI sub = (SubscriptingMI)opr;
            String opString = NodeUtil.nameString(sub.getOp());
            return evalAndInvokeMethod(front,opString,sub.getExprs(),loc);
        }
    }

    private List<Pair<MathItem,FValue>> stepThree(List<Pair<MathItem,FValue>> vs,
                                                  boolean isPostfix) {
        if (vs.size() < 1) return error("Reassociation of MathPrimary failed!");
        else if (vs.size() == 1) return vs;
        else { // vs.size() > 1
            int frontInd = 0;
            FValue front = vs.get(frontInd).getB();
            MathItem opr;
            for (Pair<MathItem,FValue> pair : IterUtil.skipFirst(vs)) {
                // 3. If there is any non-expression element (it cannot be the
                // first element)
                opr = pair.getA();
                if (!isExpr(opr)) {
                    // then replace the first such element and the element
                    // immediately preceding it (which must be an expression)
                    // with a single element that does the appropriate operator
                    // application.  This new element is an expression.
                    Pair<MathItem,FValue> app =
                        new Pair<MathItem,FValue>(dummyExpr(),
                                                  mathItemApplication((NonExprMI)opr,front,opr));
                    vs.set(frontInd, app);
                    vs.remove(frontInd+1);
                    // Reassociate the resulting sequence (which is one element
                    // shorter).
                    return reassociate(vs, isPostfix);
                }
                front = pair.getB();
                frontInd++;
            }
            return vs;
        }
    }

    private List<Pair<MathItem,FValue>> reassociate(List<Pair<MathItem,FValue>> vs, boolean isPostfix) {
        if (vs.size() == 1) return vs;
        return stepThree(stepTwo(vs, isPostfix), isPostfix);
    }

    private FValue tightJuxt(FValue first, FValue second, MathItem loc, MathPrimary x) {
        if (isFunction(first)) return functionInvocation(second,(Fcn)first,loc);
        else return functionInvocation(Useful.list(first, second),
                                       e.getValue(x.getInfixJuxt()), loc);
    }

    private FValue leftAssociate(List<Pair<MathItem,FValue>> vs, MathPrimary x) {
        // vs.size() > 1
        FValue result = vs.get(0).getB();
        for (Pair<MathItem,FValue> i : IterUtil.skipFirst(vs)) {
            result = tightJuxt(result, i.getB(), i.getA(), x);
        }
        return result;
    }

    public FValue forMathPrimary(MathPrimary x) {
        return forMathPrimary(x, false);
    }

    private FValue forMathPrimary(MathPrimary x, boolean isPostfix) {
        Expr front = x.getFront();
        FValue fval = front.accept(this);
        List<MathItem> rest = x.getRest();
        if (!rest.isEmpty()) {
            List<Pair<MathItem,FValue>> vs =
                Useful.list(new Pair<MathItem,FValue>(null, fval));
            // It is a static error if an exponentiation is immediately followed
            // by a non-expression element.
            boolean isExponentiation = false;
            for (MathItem mi : rest) {
                if (mi instanceof ExprMI)
                    vs.add(new Pair<MathItem,FValue>(mi, ((ExprMI)mi).getExpr().accept(this)));
                else { // mi instanceof NonExprMI
                    if (isExponentiation)
                       return error(x, "Syntax Error: an " +
                                    "exponentiation should not be immediately followed " +
                                    "by a subscripting or an exponentiation.");
                    vs.add(new Pair<MathItem,FValue>(mi, null));
                    isExponentiation = (mi instanceof ExponentiationMI);
                }
            }
            if (isPostfix && isExponentiation) {
                return error(x, "Syntax Error: an exponentiation should not be " +
                             "immediately followed by a postfix operator.");
            }
            if (vs.size() == 1) fval = vs.get(0).getB();
            else
                // vs.size() > 1
                // 4. Otherwise, left-associate the sequence, which has only
                // expression elements, only the last of which may be a function.
                fval = leftAssociate(reassociate(vs, isPostfix), x);
        }
        return fval;
    }

    Name fldName(AbstractFieldRef arf) {
        if (arf instanceof FieldRef) {
            return ((FieldRef)arf).getField();
        }
        if (arf instanceof _RewriteFieldRef) {
            return ((_RewriteFieldRef)arf).getField();

        }
        return bug("Unexpected AbstractFieldRef " + arf);

    }

    /** Assumes wrapped FnRefs have ids fields of length 1. */
    public FValue forTightJuxt(TightJuxt x) {
        return forTightJuxt(x, false);
    }

    private FValue forTightJuxt(TightJuxt x, boolean isPostfix) {
        List<Expr> exprs = x.getExprs();
        if (exprs.size() == 0)
            bug(x,e,"empty juxtaposition");
        Expr fcnExpr = exprs.get(0);

        if (fcnExpr instanceof FieldRef) {
            // In this case, open code the FieldRef evaluation
            // so that the object can be preserved. Alternate
            // strategy might be to generate a closure from
            // the field selection.
            FieldRef fld_sel = (FieldRef) fcnExpr;
            Expr obj = fld_sel.getObj();
            Id fld = fld_sel.getField();
            FValue fobj = obj.accept(this);
            return juxtMemberSelection(x, fobj, fld, exprs);

        } else if (fcnExpr instanceof _RewriteFieldRef) {
            // In this case, open code the FieldRef evaluation
            // so that the object can be preserved. Alternate
            // strategy might be to generate a closure from
            // the field selection.
            _RewriteFieldRef fld_sel = (_RewriteFieldRef) fcnExpr;
            Expr obj = fld_sel.getObj();
            Name fld = fld_sel.getField();
            if (fld instanceof Id) {
                FValue fobj = obj.accept(this);
                return juxtMemberSelection(x, fobj, (Id) fld, exprs);
            } else {
                NI.nyi("Field selector of dotted");
            }
        } else if (fcnExpr instanceof _RewriteFnRef) {
            // Only come here if there are static args -- must be generic
            // Note that ALL method references have been rewritten into
            // this.that form, so that bare var-ref is a function
            _RewriteFnRef rfr = (_RewriteFnRef) fcnExpr;
            Expr fn = rfr.getFn();
            List<StaticArg> args = rfr.getStaticArgs();
            if (fn instanceof AbstractFieldRef) {
                AbstractFieldRef arf = (AbstractFieldRef) fn;
                FValue fobj = arf.getObj().accept(this);
                return invokeGenericMethod(fobj,
                                           NodeUtil.nameString(fldName(arf)),
                                           args, evalInvocationArgs(exprs), x);
            } else if (fn instanceof VarRef) {
                // FALL OUT TO REGULAR FUNCTION CASE!
            } else {
                return bug(x,"_RewriteFnRef with unexpected fn " + fn);
            }
        } else if (fcnExpr instanceof FnRef) {
            // TODO this ought to be allowed.
            return bug(fcnExpr,"FnRefs are supposed to be gone from the AST \n" + x.toStringVerbose() );
        }

        FValue fnVal = fcnExpr.accept(this);
        if (fnVal instanceof MethodClosure) {
            return bug(x,"Unexpected application of " + fcnExpr);
        } else if (fnVal instanceof Fcn) {
            if (isPostfix) {
                // It is a static error if a function argument is immediately
                // followed by a non-expression element.  For example, f(x)!
                return error(x, "Syntax Error: a function argument " +
                             "should not be immediately followed by a non-expression " +
                             "element.");
            } else {
                return finishFunctionInvocation(exprs, fnVal, x);
            }
        } else {
            // When a tight juxtaposition is not a function application,
            // fake it as a loose juxtaposition.  It's clearly a hack.
            // Please fix it if you know how to do it.  -- Sukyoung
            // Less of a hack now.  -- David
            return forJuxt(x);
        }
    }

    /**
     * Unlike invokeMethod, must handle case where we have a closure-valued field.
     * @param x
     * @param fobj
     * @param fld
     * @param exprs
     * @return
     * @throws ProgramError
     */
    private FValue juxtMemberSelection(TightJuxt x, FValue fobj, Id fld,
                                       List<Expr> exprs) throws ProgramError {
        List<FValue> args = evalInvocationArgs(exprs);
        String mname = NodeUtil.nameString(fld);
        if (fobj instanceof FObject) {
            FObject fobject = (FObject) fobj;
            // TODO Need to distinguish between public/private methods/fields
            Environment se = fobject.getSelfEnv();
            FValue cl = se.getValueNull(mname);
            if (cl != null && !(cl instanceof Method) && cl instanceof Fcn) {
                // Ordinary closure, assigned to a field.
                return functionInvocation(args,(Fcn)cl, x);
            }
        }
        return invokeMethod(fobj, mname, args, x);
    }

    /**
     * @param exprs
     * @param fcnExpr
     * @return
     */
    private FValue finishFunctionInvocation(List<Expr> exprs, FValue foo,
            AbstractNode loc) {
        return functionInvocation(evalInvocationArgs(exprs), foo, loc);
    }

    /**
     * Evaluates the tail of the list, EXCLUDING THE FIRST ELEMENT.
     *
     * @param exprs
     * @return
     */
    List<FValue> evalInvocationArgs(List<Expr> exprs) {
        List<FValue> rest = evalExprListParallel(exprs.subList(1, exprs.size()));
        if (rest.size()==1) {
            FValue val = rest.get(0);
            if (val instanceof FVoid) {
                rest = new ArrayList<FValue>(0);
            } else if (val instanceof FTuple) {
                rest = ((FTuple) val).getVals();
            }
        }
        return rest;
    }

    private List<FValue> argList(FValue arg) {
        if (arg instanceof FTuple) {
            return ((FTuple) arg).getVals();
        } else {
            return Useful.list(arg);
        }
    }

    public FValue forTry(Try x) {
        Evaluator ev = new Evaluator(this, x);
        Block body = x.getBody();
        FValue res = FVoid.V;
        try {
            res = body.accept(this);
            return res;
        } catch (FortressError exc) {
            FType excType = exc.getException().type();
            Option<Catch> _catchClause = x.getCatchClause();
            if (_catchClause.isSome()) {
                Catch _catch = _catchClause.unwrap();
                Id name = _catch.getName();
                List<CatchClause> clauses = _catch.getClauses();
                for (CatchClause clause : clauses) {
                    BaseType match = clause.getMatch();
                    Block catchBody = clause.getBody();
                    FType foo = EvalType.getFType(match, e);
                    if (excType.subtypeOf(foo)) {
                        try {
                            Evaluator evClause = new Evaluator(this, _catch);
                            evClause.e.putValue(name.getText(), exc.getException());
                            return catchBody.accept(evClause);
                        } catch (FortressException err) {
                            throw err.setContext(x,e);
                        }
                    }
                }
            }
            for (BaseType forbidType : x.getForbid()) {
                if (excType.subtypeOf(EvalType.getFType(forbidType,e))) {
                    Environment libE = Driver.getFortressLibrary();
                  FType ftype = libE.getTypeNull(WellKnownNames.forbiddenException);
                  List<FValue> args = new ArrayList<FValue>();
                  args.add(exc.getException());
                  Constructor c = (Constructor) libE.getValue(WellKnownNames.forbiddenException);
                  // Can we get a better HasAt?
                  HasAt at = new HasAt.FromString(WellKnownNames.forbiddenException);
                  FObject f = (FObject) c.apply(args, at, e);
                  FortressError f_exc = new FortressError(x,e,f);
                  throw f_exc;
                }
            }
            // Nothing has handled or excluded exc; re-throw!
            throw exc;
        } finally {
            Option<Block> finallyClause = x.getFinallyClause();
            if (finallyClause.isSome()) {
                Block b = finallyClause.unwrap();
                b.accept(this);
            }
        }
    }

    public FValue forArgExpr(ArgExpr x) {
        List<Expr> exprs = x.getExprs();
        /*
        if (!isArgExpr)
            error(x, "Tuples are not allowed to have varargs or keyword expressions.");
        */
        return FTuple.make(evalExprListParallel(exprs));
    }

    public FValue forTupleExpr(TupleExpr x) {
        List<Expr> exprs = x.getExprs();
        return FTuple.make(evalExprListParallel(exprs));
    }

    public FValue forTypecase(Typecase x) {
        Evaluator ev = new Evaluator(this, x);
        List<FType> res = evalTypeCaseBinding(ev, x);
        FValue result = FVoid.V;
        List<TypecaseClause> clauses = x.getClauses();
        FType resTuple = FTypeTuple.make(res);

        for (TypecaseClause c : clauses) {
            List<Type> match = c.getMatch();
            /* Technically, match and res need not be tuples; they could be
               singletons and the subtype test below ought to be correct. */
            FType matchTuple = EvalType.getFTypeFromList(match, ev.e);

            if (resTuple.subtypeOf(matchTuple)) {
                Block body = c.getBody();
                result = evalExprList(body.getExprs(), body, ev);
                return result;
            }
        }

        Option<Block> el = x.getElseClause();
        if (el.isSome()) {
            Block elseClauses = el.unwrap();
            result = evalExprList(elseClauses.getExprs(), elseClauses, ev);
            return result;
        } else {
            // throw new MatchFailure();
            return error(x, e, errorMsg("typecase match failure given ",resTuple));
        }
    }

    public FValue forUnpastingBind(UnpastingBind x) {
        return NI("forUnpastingBind");
    }

    public FValue forUnpastingSplit(UnpastingSplit x) {
        return NI("forUnpastingSplit");
    }

    public FValue forVarRef(VarRef x) {

        FValue res = BaseEnv.toContainingObjectEnv(e, x.getLexicalDepth()).getValueNull(x);
        if (res == null) {
            Iterable<Id> names = NodeUtil.getIds(x.getVar());
            error(x, e, errorMsg("undefined variable ", names));
        }
        return res;
    }

    public FValue forVoidLiteralExpr(VoidLiteralExpr x) {
        return FVoid.V;
    }

    public FValue forWhile(While x) {
        Expr body = x.getBody();
        GeneratorClause cond = x.getTest();
        Expr test;
        if (cond.getBind().isEmpty())
            test = cond.getInit();
        else
            test = bug(x,"Undesugared generalized while expression.");
        FValue clauseVal = test.accept(this);
        if (clauseVal instanceof FBool) {
            FBool res = (FBool) clauseVal;
            while (res.getBool() != false) {
                body.accept(this);
                res = (FBool) test.accept(this);
            }
            return FVoid.V;
        } else {
            return error(test,
                         errorMsg("While condition does not have type Boolean, " +
                                  "but ", clauseVal));
        }
    }

    public FValue forThrow(Throw throw1) {
        Expr ex = throw1.getExpr();
        FObject v = (FObject) ex.accept(this);
        FortressError f_exc = new FortressError(throw1,e,v);
        throw f_exc;
        // neverReached
    }

    public FValue forCharLiteralExpr(CharLiteralExpr x) {
        return FChar.make(x.getVal());
    }

    public FValue forFloatLiteralExpr(FloatLiteralExpr x) {
        return new FFloatLiteral(x.getText(), x.getIntPart(),
                                 x.getNumerator(),
                                 x.getDenomBase(),
                                 x.getDenomPower());
    }

    public FValue forIntLiteralExpr(IntLiteralExpr x) {
        return FIntLiteral.make(x.getVal());
    }

    /*
     * (non-Javadoc)
     *
     * @see com.sun.fortress.interpreter.nodes.NodeVisitor#forFnRef(com.sun.fortress.interpreter.nodes.FnRef)
     */
    @Override
    public FValue forFnRef(FnRef x) {
        Id name = x.getFns().get(0); //x.getOriginalName();
        FValue g = forIdOfRef(name);
        bug("is this ever called?");
        return applyToActualStaticArgs(g,x.getStaticArgs(),x);
    }

    @Override
    public FValue for_RewriteObjectRef(_RewriteObjectRef that) {
        Id name = that.getObj();
        FValue g = forIdOfTLRef(name);

        if( that.getStaticArgs().isEmpty() )
            return g;
        else
            return applyToActualStaticArgs(g,that.getStaticArgs(),that);
    }

    private FValue forIdOfRef(Id x) {
        String s = x.getText();
        FValue res = e.getValueNull(s);
        if (res == null) {
            error(x, e, errorMsg("undefined variable ", x));
        }
        return res;
    }

    private FValue forIdOfTLRef(Id x) {
        FValue res = e.getValueNull(x, Environment.TOP_LEVEL);
        if (res == null) {
            error(x, e, errorMsg("undefined variable ", x));
        }
        return res;
    }

    @Override
    public FValue for_RewriteFnRef(_RewriteFnRef x) {
        Expr name = x.getFn();
        FValue g = name.accept(this);
        return applyToStaticArgs(g,x.getStaticArgs(),x);
    }

    public FValue applyToStaticArgs(FValue g, List<StaticArg> args, HasAt x) {
        if (args.size() == 0)
            return g;
        else
            return applyToActualStaticArgs(g,args,x);
    }

    public FValue applyToActualStaticArgs(FValue g, List<StaticArg> args, HasAt x) {
        if (g instanceof FGenericFunction) {
            return ((FGenericFunction) g).typeApply(args, e, x);
        } else if (g instanceof GenericConstructor) {
            return ((GenericConstructor) g).typeApply(args, e, x);
        } else if (g instanceof OverloadedFunction) {
            return((OverloadedFunction) g).typeApply(args, e, x);
        } else if (g instanceof GenericSingleton) {
            return ((GenericSingleton) g).typeApply(args, e, x);
        } else {
            return error(x, e, errorMsg("Unexpected _RewriteFnRef value, ",g));
        }
    }

    public FValue for_WrappedFValue(_WrappedFValue w) {
        return w.getFValue();
    }
}
