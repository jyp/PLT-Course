package com.sun.fortress.nodes;

import java.math.BigInteger;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Set;
import com.sun.fortress.nodes_util.*;
import com.sun.fortress.parser_util.*;
import com.sun.fortress.parser_util.precedence_opexpr.*;
import com.sun.fortress.useful.*;
import edu.rice.cs.plt.tuple.Option;

/**
 * Ellipses class _EllipsesCharSymbol.ASTGen-generated composite hierarchy.
 * Note: null is not allowed as a value for any field.
 * @version  Generated automatically by ASTGen at Tue Oct 14 14:20:44 EDT 2008
 */
@SuppressWarnings(value={"unused"})
public class _EllipsesCharSymbol extends CharSymbol implements _Ellipses {

    private final AbstractNode _repeatedNode;

    public _EllipsesCharSymbol() {
        super(new Span());
        this._repeatedNode = null;
    }

    public _EllipsesCharSymbol(Span span, AbstractNode repeatedNode){
        super(span);
        this._repeatedNode = repeatedNode;
    }

    final public AbstractNode getRepeatedNode(){ return _repeatedNode; }

    public <RetType> RetType accept(NodeVisitor<RetType> visitor) {
        return visitor.for_EllipsesCharSymbol(this);
    }
    public void accept(NodeVisitor_void visitor) {
        visitor.for_EllipsesCharSymbol(this);
    }
    public Node accept(TemplateUpdateVisitor visitor) {
        return visitor.for_EllipsesCharSymbol(this);
    }

    public boolean equals(java.lang.Object obj) {
    if (obj == null) return false;
        if ((obj.getClass() != this.getClass()) || (obj.hashCode() != this.hashCode())) {
            return false;
        }
         else {
            return false;
        }
    }


    /**
     * Implementation of hashCode that is consistent with equals.  The value of
     * the hashCode is formed by XORing the hashcode of the class object with
     * the hashcodes of all the fields of the object.
     */
    public int generateHashCode() {
        int code = getClass().hashCode();
        return code;
    }

    /** Generate a human-readable representation that can be deserialized. */
    public java.lang.String serialize() {
        java.io.StringWriter w = new java.io.StringWriter();
        serialize(w);
        return w.toString();
    }
    /** Generate a human-readable representation that can be deserialized. */
    public void serialize(java.io.Writer writer) {
        outputHelp(new TabPrintWriter(writer, 2), true);
    }

    public void outputHelp(TabPrintWriter writer, boolean lossless) {
        writer.print("_EllipsesCharSymbol:");
        writer.indent();
        Span temp_span = getSpan();
        writer.startLine();
        writer.print("span = ");
        if (lossless) {
            writer.printSerialized(temp_span);
            writer.print(" ");
            writer.printEscaped(temp_span);
        } else { writer.print(temp_span); }
        writer.unindent();
    }
}
